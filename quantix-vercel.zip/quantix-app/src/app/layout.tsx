import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Quantix Labs",
  description: "Quantix Analytics Dashboard",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
