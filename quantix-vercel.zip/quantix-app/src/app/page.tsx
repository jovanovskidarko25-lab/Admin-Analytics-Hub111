import dynamic from "next/dynamic";

// Dynamically import the app with SSR disabled because it uses
// localStorage and browser-only APIs.
const QuantixApp = dynamic(() => import("./QuantixApp"), { ssr: false });

export default function Page() {
  return <QuantixApp />;
}
